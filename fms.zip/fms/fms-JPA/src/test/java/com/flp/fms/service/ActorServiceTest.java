package com.flp.fms.service;


import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.domain.Actor;
import com.flp.fms.exceptions.DuplicateRecordFoundException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeInputException;
import com.flp.fms.exceptions.RecordDoesNotExistsException;

public class ActorServiceTest {
	 private IActorService actorService;
	 @Mock private ActorDaoImplForDB actorDao;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		actorService=new ActorServiceImpl(actorDao);
	}
	
@Test(expected=com.flp.fms.exceptions.DuplicateRecordFoundException.class)
public void whenSameDataExistsInTheAddActorThenThrowDuplicateRecordFoundException() throws FieldEmptyException, DuplicateRecordFoundException, NegativeInputException {

	Actor actor=new Actor();
	actor.setFirstName("Anuroop");
	actor.setLastName("Meka");
	List<Actor> actors=new ArrayList<Actor>();
	actors.add(actor);
	
	Map<String,String> actorDetails=new HashMap<String,String>();
	actorDetails.put("firstName","Anuroop");
	actorDetails.put("lastName","Meka");
	
	Mockito.when(actorDao.getAllActor()).thenReturn(actors);
	actorService.AddActor(actorDetails);
}

@Test
public void whenTheValidInfoIsGivenThenActorRecordMustBeSavedSuccessFully() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException {
	
	Actor actor=new Actor();
	actor.setFirstName("Anuroop");
	actor.setLastName("Meka");
	List<Actor> actors=new ArrayList<Actor>();
	actors.add(actor);
	
	Map<String,String> actorDetails=new HashMap<String,String>();
	actorDetails.put("firstName","abc");
	actorDetails.put("lastName","xyz");
	

	Mockito.when(actorDao.AddActor(actor)).thenReturn(true);
	Mockito.when(actorDao.getAllActor()).thenReturn(actors);
	//assertEquals(true,actorService.AddActor(actorDetails));
	actorService.AddActor(actorDetails);
}

@Test(expected=com.flp.fms.exceptions.RecordDoesNotExistsException.class)
public void whenTheRecordDoesNotExistsInTheRemoveActorThenThrowRecordDoesNotExistsException() throws FieldEmptyException, DuplicateRecordFoundException, NegativeInputException, RecordDoesNotExistsException {
	
	Actor actor=new Actor();
	actor.setFirstName("Anuroop");
	actor.setLastName("Meka");
	
	
	Map<String, String> remove=new HashMap<String, String>();
	remove.put("firstName", "abc");
	remove.put("lastName","xyz");
	
	Mockito.when(actorDao.SearchActor(remove)).thenReturn(null);
	actorService.RemoveActor(remove);
}

@Test
public void whenTheRecordExistsInTheRemoveActorThenItShouldRemoveSuccessFully() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException, RecordDoesNotExistsException {
	
	Actor actor=new Actor();
	actor.setFirstName("Anuroop");
	actor.setLastName("Meka");
	Mockito.when(actorDao.AddActor(actor)).thenReturn(true);
	
	Map<String, String> remove=new HashMap<String, String>();
	remove.put("firstName", "Anuroop");
	remove.put("lastName","Meka");
	
	Mockito.when(actorDao.RemoveActor(actor)).thenReturn(true);
	Mockito.when(actorDao.SearchActor(remove)).thenReturn(actor);
	
	assertEquals(true,actorService.RemoveActor(remove));
}

@Test(expected=com.flp.fms.exceptions.RecordDoesNotExistsException.class)
public void whenTheRecordDoesNotExistsInTheSearchActorThenThrowRecordDoesNotExistsException() throws FieldEmptyException, DuplicateRecordFoundException, NegativeInputException, RecordDoesNotExistsException {
	
	Actor actor=new Actor();
	actor.setFirstName("Anuroop");
	actor.setLastName("Meka");
	Mockito.when(actorDao.AddActor(actor)).thenReturn(true);
	
	Map<String, String> Search=new HashMap<String,String>();
	Search.put("firstName", "abc");
	Search.put("lastName","xyz");
	
	Mockito.when(actorDao.SearchActor(Search)).thenReturn(null);
	actorService.SearchActor(Search);
}

@Test
public void whenTheRecordExistsInTheSearchActorThenItShouldShowActorDetailsSuccessFully() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException, RecordDoesNotExistsException {
	
	Actor actor=new Actor();
	actor.setFirstName("Anuroop");
	actor.setLastName("Meka");
	Mockito.when(actorDao.AddActor(actor)).thenReturn(true);
	
	Map<String, String> Search=new HashMap<String, String>();
	Search.put("firstName", "abc");
	Search.put("lastName","xyz");
	
	Mockito.when(actorDao.RemoveActor(actor)).thenReturn(true);
	Mockito.when(actorDao.SearchActor(Search)).thenReturn(actor);
	
	assertEquals(true,actorService.RemoveActor(Search));
}

@Test
public void nullValueShouldBeReturnedIfNoActorDetailsExistsForGetAllActor() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException {
	Mockito.when(actorDao.getAllActor()).thenReturn(null);
	assertEquals(null,actorService.getAllActor());
}

@Test
public void actorsListShouldBeReturnedIfActorDetailsExistsForGetAllActor() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException {
	Actor actor=new Actor();
	actor.setFirstName("Anuroop");
	actor.setLastName("Meka");
	List<Actor> allActors = new ArrayList<Actor>();
	allActors.add(actor);
	
	Mockito.when(actorDao.getAllActor()).thenReturn(allActors);
	assertEquals(allActors,actorService.getAllActor());
}
}
