package com.flp.fms.service;

import java.util.List;
import java.util.Map;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.exceptions.DuplicateRecordFoundException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeInputException;
import com.flp.fms.exceptions.RecordDoesNotExistsException;


public class ActorServiceImpl implements IActorService
{
	IActorDao actorDao;
	
	public ActorServiceImpl() {
		actorDao=new ActorDaoImplForDB();
	}

	public ActorServiceImpl(ActorDaoImplForDB actorDao) {
		this.actorDao=actorDao;
	}
	
	public boolean AddActor(Map actorDetails) throws FieldEmptyException, DuplicateRecordFoundException, NegativeInputException 
	{
		Actor actor=new Actor();
		actor.setFirstName((String) actorDetails.get("firstName"));
		actor.setLastName((String) actorDetails.get("lastName"));
		if(actorDao.getAllActor().contains(actor))
		{
			throw new DuplicateRecordFoundException();
		}
		return actorDao.AddActor(actor);
	}
	
	
	public boolean ModifyActor(Map actorDetails) throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException  {

		Actor actor=actorDao.SearchActorById((Integer) actorDetails.get("actorId"));
		actor.setFirstName((String) actorDetails.get("firstName"));
		actor.setLastName((String) actorDetails.get("lastName"));
		return actorDao.ModifyActor(actor);
	}

	
	public boolean RemoveActor(Map actorDetails)  throws NegativeInputException, RecordDoesNotExistsException, FieldEmptyException{
		Actor actor=actorDao.SearchActor(actorDetails);
		if(actor==null)
		{
			throw new RecordDoesNotExistsException();
		}
		return actorDao.RemoveActor(actor);
	}

	
	public Actor SearchActor(Map actorDetails) throws FieldEmptyException, NegativeInputException, RecordDoesNotExistsException {

		if(actorDetails==null)
		{
			throw new RecordDoesNotExistsException();
		}
		
		return actorDao.SearchActor(actorDetails);

	}

	
	public List<Actor> getAllActor() {
		return actorDao.getAllActor();
	}
}
