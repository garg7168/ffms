package com.flp.fms.service;

import java.text.ParseException;
import java.util.List;
import java.util.Map;
import com.flp.fms.domain.Film;
import com.flp.fms.exceptions.DuplicateRecordFoundException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeInputException;
import com.flp.fms.exceptions.RecordDoesNotExistsException;

public interface IFilmService 
{
	boolean AddFilm(Map filmDetails) throws ParseException, FieldEmptyException, NegativeInputException, DuplicateRecordFoundException ;
	boolean ModifyFilm(Map modify) throws FieldEmptyException, NegativeInputException, RecordDoesNotExistsException;
	boolean RemoveFilm(int id) throws FieldEmptyException, NegativeInputException, RecordDoesNotExistsException ;
	Film SearchFilm(int id) throws FieldEmptyException, NegativeInputException, RecordDoesNotExistsException ;
	List<Film> getAllFilm();
	
}
