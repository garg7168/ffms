package com.flp.fms.exceptions;

public class DuplicateRecordFoundException extends Exception {

}
