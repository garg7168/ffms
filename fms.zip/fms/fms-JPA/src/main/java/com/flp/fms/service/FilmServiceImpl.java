package com.flp.fms.service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.exceptions.DuplicateRecordFoundException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.RecordDoesNotExistsException;
import com.flp.fms.exceptions.NegativeInputException;
import com.flp.fms.view.UserInteraction;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;


public class FilmServiceImpl implements IFilmService
{
	IFilmDao filmDao;
	IActorDao actorDao;
	
	public FilmServiceImpl() 
	{
		filmDao=new FilmDaoImplForDB();
		actorDao=new ActorDaoImplForDB();
	}
	
	
	public FilmServiceImpl(IFilmDao filmDao) 
	{
		this.filmDao=filmDao;
		
	}
	
	public boolean AddFilm(Map filmDetails) throws ParseException,FieldEmptyException, NegativeInputException, DuplicateRecordFoundException
	{
		Set<String> keys=filmDetails.keySet();
		
		for(String key:keys)
		{
			if((((filmDetails.get(key)).getClass()).equals(Integer.class))  && (((Integer)filmDetails.get(key)) < 0))
			{
				throw new NegativeInputException();
			}
			else if((((filmDetails.get(key)).getClass()).equals(String.class))  && (((String)filmDetails.get(key)).equals("") || (((String)filmDetails.get(key)).equals("null"))))
			{
				throw new FieldEmptyException();
			}
		}
			
		Film film=new Film();
		film.setTitle((String) filmDetails.get("title"));
		film.setRating((Integer) filmDetails.get("rating"));
		film.setReleaseYear((Date) filmDetails.get("releaseDate"));
		
		if(getAllFilm().contains(film))
		{
			throw new DuplicateRecordFoundException();
		}
		
		film.setDescription((String) filmDetails.get("description"));
		film.setRentalDuration( (Integer) filmDetails.get("rentalDuration"));
		film.setRentalRate((Integer) filmDetails.get("rentalRate"));
		film.setLength((Integer) filmDetails.get("length"));
		film.setReplacementCost((Integer) filmDetails.get("replacementCost"));
		film.setSpecialFeatures((String) filmDetails.get("specialFeatures"));
		
		Language lang=filmDao.findLanguageByName((String) filmDetails.get("languageName"));
		if(lang == null)
		{
			lang=new Language((String) filmDetails.get("languageName"));
		}
		film.setLanguage(lang);
		
		Category catg=filmDao.findCategoryByName((String) filmDetails.get("categoryName"));
		if(catg == null)
		{
			catg=new Category((String) filmDetails.get("categoryName"));
		}
		film.setCategory(catg);
		
		
		List<Actor> actors=actorDao.getAllActor();
		
		for(int i=0; i < ((List) filmDetails.get("actors")).size(); i++)
		{
			Actor actor=new Actor();
			actor.setFirstName((String) ((Map) ((List) filmDetails.get("actors")).get(i)).get("firstName"));
			actor.setLastName((String) ((Map) ((List) filmDetails.get("actors")).get(i)).get("lastName"));
			
			if(actors == null || !actors.contains(actor))
			{
				film.getActors().add(actor);
			}
			else
			{
				film.getActors().add(actorDao.findActorByName(actor.getFirstName(),actor.getLastName()));
			}
		}
		
		filmDao.AddFilm(film);
		return true;
	}
	
	public boolean ModifyFilm(Map modify) throws FieldEmptyException, NegativeInputException, RecordDoesNotExistsException
	{
		Film film=filmDao.SearchFilm((Integer)modify.get(1));
		if(film!=null){
		if(modify.get(2)!=null){
		film.setTitle((String)modify.get(2));
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(3)!=null){
		film.setDescription((String)modify.get(3));
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(4)!=null){
		Language language=new Language();
		language.setLanguageName((String)modify.get(4));
		film.setLanguage(language);
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(5)!=null){
		film.setRentalDuration(((Integer)modify.get(5)));
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(6)!=null){
		film.setRentalRate(((Integer)modify.get(6)));
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(7)!=null){
		film.setLength((((Integer)modify.get(7))));
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(8)!=null){
		film.setReplacementCost((((Integer)modify.get(8))));
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(9)!=null){
		film.setRating((Integer)modify.get(9));
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(10)!=null){
		film.setSpecialFeatures(((String)modify.get(10)));
		return filmDao.ModifyFilm(film);
		}
		else if(modify.get(11)!=null){
		Category category=new Category();
		category.setCategoryName((String)modify.get(11));
		film.setCategory(category);
		return filmDao.ModifyFilm(film);
		}
		else
		return false;
		 
		}
		return false;
		 
		 
		}

	public boolean RemoveFilm(int id) throws FieldEmptyException, NegativeInputException, RecordDoesNotExistsException
	{      
		if (id <=0)
		{
			throw new NegativeInputException();
		}
		else 
		{
			return filmDao.RemoveFilm(id);
		}
		
			
			
	}
	
	public Film SearchFilm(int id)  throws FieldEmptyException, NegativeInputException, RecordDoesNotExistsException
	{
		if (id <=0)
		{
			throw new NegativeInputException();
		}
		else 
		{
		return filmDao.SearchFilm(id);
		}
		
	}

	public List<Film> getAllFilm() 
	{
		return filmDao.getAllFilm();
	}
	
}
