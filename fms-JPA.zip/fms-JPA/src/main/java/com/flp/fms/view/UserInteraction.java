package com.flp.fms.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.exceptions.DuplicateRecordFoundException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.RecordDoesNotExistsException;
import com.flp.fms.exceptions.NegativeInputException;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;


public class UserInteraction
{
	IFilmService filmService;
	IActorService actorService;
	Scanner sc=new Scanner(System.in);

	public UserInteraction()
	{
		filmService=new FilmServiceImpl();
		actorService=new ActorServiceImpl();
	}
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	public void AddFilm() throws ParseException, FieldEmptyException, NegativeInputException, DuplicateRecordFoundException
	{
		Map<String, Object> filmDetails=new HashMap<String, Object>();
		
		System.out.println("Enter title");
		filmDetails.put("title",sc.nextLine());
		
		System.out.println("Enter description");
		filmDetails.put("description",sc.nextLine());
		
		System.out.println("Enter release date in yyyy-mm-dd");
		filmDetails.put("releaseDate",dateFormat.parse(sc.nextLine()));
		
		System.out.println("Enter rental duration");
		filmDetails.put("rentalDuration",Integer.parseInt(sc.nextLine()));
		
		System.out.println("Enter rental rate");
		filmDetails.put("rentalRate",Integer.parseInt(sc.nextLine()));
		
		System.out.println("Enter length of the movie");
		filmDetails.put("length",Integer.parseInt(sc.nextLine()));
		
		System.out.println("Enter replacement cost");
		filmDetails.put("replacementCost",Integer.parseInt(sc.nextLine()));
		
		System.out.println("Enter rating");
		filmDetails.put("rating",Integer.parseInt(sc.nextLine()));
		
		System.out.println("Enter special features");
		filmDetails.put("specialFeatures",sc.nextLine());
				
		
		System.out.println("Enter the language Name");
		filmDetails.put("languageName",sc.nextLine());

		System.out.println("Enter the category Name");
		filmDetails.put("categoryName",sc.nextLine());
	
		System.out.println("Enter the Number of actors");
		int numberOfActors=Integer.parseInt(sc.nextLine());
		
		List actors=new ArrayList();
		for(int i=1;i <= numberOfActors;i++)
		{
			Map<String, String> actorDetails=new HashMap<String, String>();
			System.out.println("Enter the actor first name");
			actorDetails.put("firstName",sc.next());
			System.out.println("Enter the actor last name");
			actorDetails.put("lastName",sc.next());
			actors.add(actorDetails);
		}
		
		filmDetails.put("actors",actors);
		filmService.AddFilm(filmDetails);
		System.out.println("Film added Successfully");
	}
	
	public void ModifyFilm() throws ParseException, FieldEmptyException, NegativeInputException, RecordDoesNotExistsException
	{
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			Map<Integer,Object> newDetails=new HashMap();
			System.out.println("enter id of the film to modify");
			int id=sc.nextInt();
			newDetails.put(1,id);
			System.out.println("enter choice to modify 1.title 2.description 3.language 4.rental_duration 5.rental_rate 6.length 7.replacement_cost 8.rating 9.special_features 10.category");
			int choice=sc.nextInt();
			switch(choice){
			 
			case 1:System.out.println("enter new title");
			String title=sc.next();
			newDetails.put(2, title);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			 
			case 2:System.out.println("enter new description");
			String description=sc.next();
			newDetails.put(3, description);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			 
			case 3:System.out.println("enter new language");
			String language=sc.next();
			newDetails.put(4, language);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			 
			case 4:System.out.println("enter new rental_duration");
			int rentalDuration=sc.nextInt();
			newDetails.put(5, rentalDuration);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			case 5:System.out.println("enter new rental_rate");
			Double rentalRate=sc.nextDouble();
			newDetails.put(6, rentalRate);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			case 6:System.out.println("enter new length");
			int length=sc.nextInt();
			newDetails.put(7, length);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			 
			case 7:System.out.println("enter new replacement cost");
			Double replacementCost=sc.nextDouble();
			newDetails.put(8, replacementCost);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			 
			 
			case 8:System.out.println("enter new rating");
			Double rating=sc.nextDouble();
			newDetails.put(9, rating);
						System.out.println(filmService.ModifyFilm(newDetails));
			break;
			 
			 
			case 9:System.out.println("enter new special features");
			String specialFeatures=sc.next();
			newDetails.put(10, specialFeatures);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			case 10:System.out.println("enter new Category");
			String category=sc.next();
			newDetails.put(11, category);
			System.out.println(filmService.ModifyFilm(newDetails));
			break;
			}
			 
			 
			}
	
	public void RemoveFilm() throws ParseException, FieldEmptyException, NegativeInputException, RecordDoesNotExistsException
	{
		System.out.println("Enter the id to remove film");
		System.out.println("Film Removal status is "+filmService.RemoveFilm(sc.nextInt()));
	}
	
	public void SearchFilm() throws FieldEmptyException, NegativeInputException, RecordDoesNotExistsException
	{
		/*Map<String, Object> search=new HashMap<String, Object>();
		System.out.println("Search Menu");
		System.out.println("-------------------------------------------------");
		System.out.println("1.By film Title"+"\n"+"2.By Actor Id"+"\n"+"3.By Rating"+"\n"+"4.By Language Id"+"\n"+"5.By Category Id"+"\n"+"6.By Actor Name"+"\n"+"7.By Language Name"+"\n"+"8.By Category Name"+"\n");
		System.out.println("enter the choice of search");
		int ch=Integer.parseInt(sc.nextLine());
		
		switch(ch)
		{
			case 1:System.out.println("enter the film title");
					search.put("title", sc.nextLine());
					break;
			case 2:System.out.println("enter the Actor Id");
					search.put("actorId", Integer.parseInt(sc.nextLine()));
					break;
			case 3:System.out.println("enter the rating");
					search.put("rating", Integer.parseInt(sc.nextLine()));
					break;
			case 4:System.out.println("enter the Language Id");
					search.put("languageId", Integer.parseInt(sc.nextLine()));
					break;
			case 5:System.out.println("enter the Category Id");
					search.put("categoryId", Integer.parseInt(sc.nextLine()));
					break;
			case 6:System.out.println("enter the Actor First Name");
					search.put("firstName", sc.nextLine());
					System.out.println("enter the Actor last Name");
					search.put("lastName", sc.nextLine());
					break;
			case 7:System.out.println("enter the Language Name");
					search.put("languageName", sc.nextLine());
					break;
			case 8:System.out.println("enter the Category Name");
					search.put("categoryName", sc.nextLine());
					break;
			
			default:System.out.println("Invalid Search choice");
					break;
		}
		if(ch <=8 )
		{
			System.out.println("Film Details are "+filmService.SearchFilm(search));
		}*/
		System.out.println("enter id to search");
		int id=sc.nextInt();
		System.out.println(filmService.SearchFilm(id));
	}
	
	public void getAllFilm() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException
	{
		List<Film> films=filmService.getAllFilm();
		System.out.println("All films details are "+films);
	}
	
	public void AddActor() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException
	{
		Map<String, String> actorDetails=new HashMap<String, String>();
		System.out.println("Enter the actor first name");
		actorDetails.put("firstName",sc.nextLine());
		System.out.println("Enter the actor last name");
		actorDetails.put("lastName",sc.nextLine());
		actorService.AddActor(actorDetails);
		
		System.out.println("Actor added Successfully");
	}
	
	public void ModifyActor() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException
	{
		Map<Object, Object> actorDetails=new HashMap<Object, Object>();
		System.out.println("Enter the actor id to modify");
		actorDetails.put("actorId",Integer.parseInt(sc.nextLine()));
		System.out.println("Enter the actor modified first name");
		actorDetails.put("firstName",sc.nextLine());
		System.out.println("Enter the actor modified last name");
		actorDetails.put("lastName",sc.nextLine());
		System.out.println("Actor details modified status is "+actorService.ModifyActor(actorDetails));	
	}
	
	public void RemoveActor() throws NegativeInputException, RecordDoesNotExistsException, FieldEmptyException
	{
		Map<String, String> actorDetails=new HashMap<String, String>();
		System.out.println("Enter the actor first name");
		actorDetails.put("firstName",sc.nextLine());
		System.out.println("Enter the actor last name");
		actorDetails.put("lastName",sc.nextLine());
		
		System.out.println("Actor Removal status is "+actorService.RemoveActor(actorDetails));
	}
	
	public void SearchActor() throws NegativeInputException, RecordDoesNotExistsException, FieldEmptyException
	{
		Map<String, String> actorDetails=new HashMap<String, String>();
		System.out.println("Enter the actor first name");
		actorDetails.put("firstName",sc.nextLine());
		System.out.println("Enter the actor last name");
		actorDetails.put("lastName",sc.nextLine());
		
		System.out.println("All actors details are "+actorService.SearchActor(actorDetails));
	}
	
	public void getAllActor()
	{
		List<Actor> actors= actorService.getAllActor();
		System.out.println("All actors details are "+actors);
	}
}
