package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.entitymanager.EntityManagerCreator;

public class FilmDaoImplForDB implements IFilmDao
{
	EntityManagerCreator creator=new EntityManagerCreator();
	EntityManager em=creator.openEntityManger();

	public boolean AddFilm(Film film) 
	{
		if(film != null)
		{
			em.getTransaction().begin();
			em.persist(film);
			em.getTransaction().commit();
			return true;
		}
		return false;
	}

	public boolean ModifyFilm(Film film) {
		
		em.getTransaction().begin();
		em.persist(film);
		em.getTransaction().commit();
		return true;
	}

	public boolean RemoveFilm(int id) {
		Film film=SearchFilm(id);
		if(film != null)
		{
			em.getTransaction().begin();
			em.remove(film);
			em.getTransaction().commit();
			return true;
		}
		return false;
	}

	public Film SearchFilm(int id) {
	
		return em.find(Film.class, id);
	}

	public List<Film> getAllFilm() {
		TypedQuery<Film> query = em.createQuery("Select f from Film f",Film.class);
		return query.getResultList();
		
	}
	
	public Language findLanguageByName(String languageName){
		TypedQuery<Language> query = em.createQuery("Select l from Language l where l.languageName='"+languageName+"' ",Language.class);
		
		if(query.getResultList().size() > 0)
		{
			return query.getSingleResult();
		}
		return null;
	}
	
	public Category findCategoryByName(String categoryName){
		TypedQuery<Category> query = em.createQuery("Select c from Category c where c.categoryName='"+categoryName+"'",Category.class);
		
		if(query.getResultList().size() > 0)
		{
			return query.getSingleResult();
		}
		return null;
	}

}
