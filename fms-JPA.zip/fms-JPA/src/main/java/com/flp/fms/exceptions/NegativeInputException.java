package com.flp.fms.exceptions;

public class NegativeInputException extends Exception{

}
