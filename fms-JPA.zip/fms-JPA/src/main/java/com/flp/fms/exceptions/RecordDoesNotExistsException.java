package com.flp.fms.exceptions;

public class RecordDoesNotExistsException extends Exception{

}
