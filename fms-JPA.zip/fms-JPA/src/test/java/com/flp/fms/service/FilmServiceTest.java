package com.flp.fms.service;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.flp.fms.dao.ActorDaoImplForDB;
import com.flp.fms.dao.FilmDaoImplForDB;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.exceptions.DuplicateRecordFoundException;
import com.flp.fms.exceptions.FieldEmptyException;
import com.flp.fms.exceptions.NegativeInputException;
import com.flp.fms.exceptions.RecordDoesNotExistsException;

public class FilmServiceTest {
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	private IFilmService filmService;
	@Mock private FilmDaoImplForDB filmDao;
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		filmService = new FilmServiceImpl(filmDao);
	}
	
	@Test(expected=com.flp.fms.exceptions.FieldEmptyException.class)
	public void whenTheFieldIsEmptyThrowsFieldEmptyException() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException, ParseException {
		
		Map <String,Object> filmDetails=new HashMap<String,Object>();
		filmDetails.put("Description", "null");
		filmDetails.put("rating", 1);
		filmService.AddFilm(filmDetails);
	}

	@Test(expected=com.flp.fms.exceptions.NegativeInputException.class)
	public void whenTheFieldValueIsNegativeThrowsNegativeInputException() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException, ParseException {
		
		Map <String,Object> filmDetails=new HashMap<String,Object>();
		filmDetails.put("title", "IceAge");
		filmDetails.put("rating", -1);
		filmService.AddFilm(filmDetails);	
	}

	@Test(expected=com.flp.fms.exceptions.DuplicateRecordFoundException.class)
	public void whenTheFieldValueIsSameThrowsDuplicateRecordFoundException() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException, ParseException {
		
		Film film=new Film();
		film.setTitle("IceAge");
		film.setRating(5);
		film.setReleaseYear((Date) dateFormat.parse("2016-06-10"));
		List<Film> films=new ArrayList<Film>();
		films.add(film);
		
		Map<String, Object> newFilm=new HashMap<String, Object>();
		newFilm.put("title", "IceAge");
		newFilm.put("rating", 5);
		newFilm.put("releaseDate",dateFormat.parse("2016-06-10"));
		Mockito.when(filmDao.getAllFilm()).thenReturn(films);
		filmService.AddFilm(newFilm);
	}
	
	@Test
	public void whenTheFieldValueIsDifferentItShouldAddInDataBase() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException, ParseException {
		
			Film film=new Film();
			film.setTitle("IceAge");
			film.setDescription("abcd");
			film.setReleaseYear((Date) dateFormat.parse("2016-01-01"));
			film.setRentalDuration(1);
			film.setRentalRate(2);
			film.setLength(3);
			film.setReplacementCost(4);
			film.setRating(5);
			film.setSpecialFeatures("effects");
			Category catg=new Category();
			Language lang=new Language();
			catg.setCategoryName("animation");
			lang.setLanguageName("english");
			Actor actor=new Actor();
			actor.setFirstName("abc");
			actor.setLastName("xyz");
			
			List<Actor> actors=new ArrayList<Actor>();
			actors.add(actor);
			film.setActors(actors);
			film.setCategory(catg);
			film.setLanguage(lang);
			Mockito.when(filmDao.AddFilm(film)).thenReturn(true);
			filmDao.AddFilm(film);
			
			List<Film> allFilms=new ArrayList<Film>();
			allFilms.add(film);
			
			Map<String, Object> newFilm=new HashMap<String, Object>();
			newFilm.put("title", "Marvel");
			newFilm.put("description", "abcd");
			newFilm.put("rating",5);
			newFilm.put("length",2);
			newFilm.put("replacementCost",3);
			newFilm.put("rentalRate",4);
			newFilm.put("rentalDuration",3);
			newFilm.put("specialFeatures","graphics");
			newFilm.put("releaseDate",dateFormat.parse("2016-02-0"));
			newFilm.put("languageName","english");
			newFilm.put("categoryName","action");
			
			List newActors=new ArrayList();
			Map<String, String> actorDetails=new HashMap<String, String>();
			actorDetails.put("firstName","anuroop");
			actorDetails.put("lastName","meka");
			newActors.add(actorDetails);
			newFilm.put("actors",newActors);
			
			//Mockito.when(filmDao.AddFilm(film)).thenReturn(true);
			//Mockito.when(actorDao.getAllActor()).thenReturn(actors);
			//Mockito.when(filmDao.getAllFilm()).thenReturn(allFilms);
			assertEquals(true,filmService.AddFilm(newFilm));
		
		}
	
	@Test(expected=com.flp.fms.exceptions.NegativeInputException.class)
	public void whenIdIsNegativeInRemoveFilmThrowNegativeInputException() throws  NegativeInputException, DuplicateRecordFoundException, ParseException, RecordDoesNotExistsException, FieldEmptyException {

		filmService.RemoveFilm(-1);
	
		}
	
	@Test
	public void whenValidIdIsGivenInRemoveFilmThenFilmDetailsSholudRemoveSuccessfully() throws NegativeInputException, DuplicateRecordFoundException, ParseException, RecordDoesNotExistsException, FieldEmptyException {
		
		Mockito.when(filmDao.RemoveFilm(1)).thenReturn(true);
		assertEquals(true,filmService.RemoveFilm(1));
		
	}
	
	@Test(expected=com.flp.fms.exceptions.NegativeInputException.class)
	public void whenIdIsNegativeInSearchFilmThrowNegativeInputException() throws  NegativeInputException, DuplicateRecordFoundException, ParseException, RecordDoesNotExistsException, FieldEmptyException {

		filmService.SearchFilm(-1);
	
		}
	
	@Test
	public void whenValidIdIsGivenInSearchFilmThenFilmDetailsSholudSearchSuccessfully() throws NegativeInputException, DuplicateRecordFoundException, ParseException, RecordDoesNotExistsException, FieldEmptyException {
		
		Film film=new Film();
		film.setFilmId(1);
		film.setTitle("IceAge");
		film.setDescription("abcd");
		film.setReleaseYear((Date) dateFormat.parse("2016-01-01"));
		film.setRentalDuration(1);
		film.setRentalRate(2);
		film.setLength(3);
		film.setReplacementCost(4);
		film.setRating(5);
		film.setSpecialFeatures("effects");
		Category catg=new Category();
		Language lang=new Language();
		catg.setCategoryName("animation");
		lang.setLanguageName("english");
		Actor actor=new Actor();
		actor.setFirstName("abc");
		actor.setLastName("xyz");
		List<Actor> actors=new ArrayList<Actor>();
		actors.add(actor);
		film.setActors(actors);
		film.setCategory(catg);
		film.setLanguage(lang);
		
		Mockito.when(filmDao.SearchFilm(2)).thenReturn(film);
		assertEquals(film,filmService.SearchFilm(2));
	}
	

	@Test
	public void nullValueShouldBeReturnedIfNoFilmDetailsExistsForGetAllActor() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException {
		
		Mockito.when(filmDao.getAllFilm()).thenReturn(null);
		assertEquals(null,filmService.getAllFilm());
	}
	
	@Test
	public void actorsListShouldBeReturnedIfFilmDetailsExistsForGetAllActor() throws FieldEmptyException, NegativeInputException, DuplicateRecordFoundException, ParseException {
		
		Film film=new Film();
		film.setTitle("janatha garage");
		film.setDescription("mass entertainer");
		film.setReleaseYear((Date) dateFormat.parse("2016-09-02"));
		film.setRentalDuration(1);
		film.setRentalRate(2);
		film.setLength(3);
		film.setReplacementCost(4);
		film.setRating(5);
		film.setSpecialFeatures("enteratainer");
		Category catg=new Category();
		Language lang=new Language();
		catg.setCategoryName("mass");
		lang.setLanguageName("telugu");
		Actor actor=new Actor();
		actor.setFirstName("ntr");
		actor.setLastName("jr");
		List<Actor> actors=new ArrayList<Actor>();
		actors.add(actor);
		film.setCategory(catg);
		film.setLanguage(lang);
		List<Film> films=new ArrayList<Film>();
		films.add(film);
		
		Mockito.when(filmDao.getAllFilm()).thenReturn(films);
		assertEquals(films,filmService.getAllFilm());
	}
	
}
